import { Routes } from '@angular/router';
import { FacturaFormComponent } from './modules/parqueadero/components/factura-form/factura-form.component';
import { ListadoVehiculosComponent } from './modules/parqueadero/components/listado-vehiculos/listado-vehiculos.component';
import { IngresoFormComponent } from './modules/parqueadero/components/ingreso-form/ingreso-form.component';
import { SalidaFormComponent } from './modules/parqueadero/components/salida-form/salida-form.component';

export const routes: Routes = [
  { path: 'factura/nueva/:ingresoID', component: FacturaFormComponent },
  { path: 'factura-form/:ingresoID', component: FacturaFormComponent },
  { path: 'listado-vehiculos', component: ListadoVehiculosComponent },
  { path: 'ingreso-form', component: IngresoFormComponent },
  { path: 'salida-form/:ingresoID', component: SalidaFormComponent },
  { path: '**', redirectTo: 'listado-vehiculos' }
];