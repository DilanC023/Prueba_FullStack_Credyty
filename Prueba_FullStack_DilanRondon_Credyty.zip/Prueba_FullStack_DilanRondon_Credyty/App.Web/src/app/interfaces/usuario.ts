export interface IUsuario {
    usuarioID: number
    nombre: string
    documentoIdentidad: string
    email: string
    clave: string
    fechaCreacion: string
}