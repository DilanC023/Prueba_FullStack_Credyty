export interface ITarifa {
    tarifaID: number
    tipoVehiculo: string
    precioPorMinuto: number
  }