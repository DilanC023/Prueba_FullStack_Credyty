export interface IAutenticacion {
    email: string,
    clave: string,
}