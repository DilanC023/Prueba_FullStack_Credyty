export interface IVehiculo {
    id: number;
    placa: string;
    tipo: string;
  }