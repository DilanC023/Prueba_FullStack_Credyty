export interface IToken {
    token: string,
    tipo: string,
    expira: Date
}