export interface IFactura {
    facturaID: number
    ingresoID: number
    numeroFactura: string
  }
  