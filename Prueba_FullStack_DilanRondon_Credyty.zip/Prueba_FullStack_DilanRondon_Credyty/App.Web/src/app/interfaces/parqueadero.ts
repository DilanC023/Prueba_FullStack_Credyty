export interface IParqueadero {
    ingresoID: number
    vehiculoID: number
    horaIngreso: string
    horaSalida?: string
    valorPagado?: number
    descuentoAplicado: boolean
    tipoVehiculo: string
    placa: string
    documentoIdentidad: string
  }
  