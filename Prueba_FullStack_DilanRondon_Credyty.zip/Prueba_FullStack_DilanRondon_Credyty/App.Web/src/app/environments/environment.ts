export const environments ={
    InProc: false,
    UrlApi: 'https://localhost:44330/api/'
}