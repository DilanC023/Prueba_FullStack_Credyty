import { inject, Injectable } from '@angular/core';
import { environments } from '../environments/environment';
import { HttpClient } from '@angular/common/http';
import { IParqueadero } from '../interfaces/parqueadero';
import { Observable } from 'rxjs';
import { AutenticacionService } from './autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class ParqueaderoService {
  private apiUrl = environments.UrlApi;
  private http = inject(HttpClient); 

  constructor(private autenticacionService: AutenticacionService){}

  ObtenerIngresos(): Observable<IParqueadero[]> {
    return this.http.get<IParqueadero[]>(`${this.apiUrl}Parqueadero/ingresos`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ObtenerIngresoPorId(id: number): Observable<IParqueadero> {
    return this.http.get<IParqueadero>(`${this.apiUrl}Parqueadero/ingreso/${id}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  RegistrarIngreso(IParqueadero: IParqueadero): Observable<boolean> {
    return this.http.post<boolean>(`${this.apiUrl}Parqueadero/ingreso`, IParqueadero,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ModificarIngreso(id: number, IParqueadero: IParqueadero): Observable<boolean> {
    return this.http.put<boolean>(`${this.apiUrl}Parqueadero/ingreso/${id}`, IParqueadero,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  EliminarIngreso(id: number): Observable<boolean> {
    return this.http.delete<boolean>(`${this.apiUrl}Parqueadero/ingreso/${id}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }


}
