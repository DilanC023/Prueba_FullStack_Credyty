import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { environments } from '../environments/environment';
import { Observable } from 'rxjs';
import { IFactura } from '../interfaces/factura';
import { AutenticacionService } from './autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class FacturaService {
  private urlApi = environments.UrlApi;
  private http = inject(HttpClient);
  constructor(private autenticacionService: AutenticacionService){}
  ObtenerFacturas(): Observable<IFactura[]> {
    return this.http.get<IFactura[]>(`${this.urlApi}Factura/facturas`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ObtenerFacturaPorId(id: number): Observable<IFactura> {
    return this.http.get<IFactura>(`${this.urlApi}Factura/factura/${id}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  AdicionarFactura(factura: IFactura): Observable<boolean> {
    return this.http.post<boolean>(`${this.urlApi}Factura/factura`, factura,{ headers: this.autenticacionService.obtenerHeaders() });
  }
}
