import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environments } from '../environments/environment';
import { Observable, tap } from 'rxjs';
import { IToken } from '../interfaces/token';
import { IUsuario } from '../interfaces/usuario';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionService {
  private urlApi = environments.UrlApi;
  private http = inject(HttpClient);
  private tokenKey = 'auth_token'; 

  Autenticacion(): Observable<IToken> {
    const credenciales = { email: "prueba@prueba.com", clave: "Dilan123" };
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    return this.http.post<IToken>(`${this.urlApi}Autenticacion/login`, credenciales, { headers });
  }

  AdicionarUsuario(usuario: IUsuario): Observable<boolean> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.post<boolean>(`${this.urlApi}Autenticacion/adicionar`, usuario, { headers });
  }

  obtenerHeaders(): HttpHeaders {
    const token = localStorage.getItem(this.tokenKey);
    let headers = new HttpHeaders({ 'Content-Type': 'application/json' });

    if (token) {
      headers = headers.set('Authorization', `Bearer ${token}`);
    }

    return headers;
  }

  cerrarSesion() {
    localStorage.removeItem(this.tokenKey);
  }

  estaAutenticado(): boolean {
    return !!this.obtenerHeaders();
  }
}
