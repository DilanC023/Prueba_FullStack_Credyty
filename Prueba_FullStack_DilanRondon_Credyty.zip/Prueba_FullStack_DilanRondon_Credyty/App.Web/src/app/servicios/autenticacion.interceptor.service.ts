import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AutenticacionInterceptorService implements HttpInterceptor {

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    // Obtener el token almacenado en localStorage o sessionStorage
    const token = localStorage.getItem('auth_token'); // También puedes usar sessionStorage si prefieres

    if (token) {
      // Clonar la solicitud y agregar el token en los headers
      const authReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
      return next.handle(authReq);
    }

    // Si no hay token, se envía la solicitud sin modificar
    return next.handle(req);
  }
}
