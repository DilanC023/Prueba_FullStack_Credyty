import { inject, Injectable } from '@angular/core';
import { environments } from '../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ITarifa } from '../interfaces/tarifa';
import { AutenticacionService } from './autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class TarifaService {
  private urlApi = environments.UrlApi;
  private http = inject(HttpClient);

  constructor(private autenticacionService: AutenticacionService){}

  ObtenerTarifaPorTipo(tipoVehiculo: string): Observable<ITarifa> {
    return this.http.get<ITarifa>(`${this.urlApi}/${tipoVehiculo}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ModificarTarifa(tarifa: ITarifa): Observable<boolean> {
    return this.http.put<boolean>(`${this.urlApi}`, tarifa,{ headers: this.autenticacionService.obtenerHeaders() });
  }
}
