import { inject, Injectable } from '@angular/core';
import { environments } from '../environments/environment';
import { HttpClient } from '@angular/common/http';
import { IVehiculo } from '../interfaces/vehiculo';
import { Observable } from 'rxjs';
import { AutenticacionService } from './autenticacion.service';

@Injectable({
  providedIn: 'root'
})
export class IVehiculoService {
  private urlApi = environments.UrlApi;
  private http = inject(HttpClient);
  constructor(private autenticacionService: AutenticacionService){}

  ObtenerIVehiculos(): Observable<IVehiculo[]> {
    return this.http.get<IVehiculo[]>(`${this.urlApi}Vehiculo/`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ObtenerIVehiculoPorId(id: number): Observable<IVehiculo> {
    return this.http.get<IVehiculo>(`${this.urlApi}Vehiculo/${id}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  RegistrarIVehiculo(IVehiculo: IVehiculo): Observable<boolean> {
    return this.http.post<boolean>(`${this.urlApi}Vehiculo/`, IVehiculo,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  ModificarIVehiculo(id: number, IVehiculo: IVehiculo): Observable<boolean> {
    return this.http.put<boolean>(`${this.urlApi}Vehiculo/${id}`, IVehiculo,{ headers: this.autenticacionService.obtenerHeaders() });
  }

  EliminarIVehiculo(id: number): Observable<boolean> {
    return this.http.delete<boolean>(`${this.urlApi}Vehiculo/${id}`,{ headers: this.autenticacionService.obtenerHeaders() });
  }
}
