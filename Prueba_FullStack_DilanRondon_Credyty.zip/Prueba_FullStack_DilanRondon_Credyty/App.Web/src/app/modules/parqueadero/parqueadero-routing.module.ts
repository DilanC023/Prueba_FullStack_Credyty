import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IngresoFormComponent } from './components/ingreso-form/ingreso-form.component';

const routes: Routes = [
  { path: 'ingreso', component: IngresoFormComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ParqueaderoRoutingModule { }
