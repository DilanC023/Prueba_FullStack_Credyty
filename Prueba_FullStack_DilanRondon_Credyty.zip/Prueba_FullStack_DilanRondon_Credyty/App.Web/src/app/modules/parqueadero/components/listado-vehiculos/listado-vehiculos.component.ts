import { Component, OnInit } from '@angular/core';
import { MatTableModule } from '@angular/material/table';
import { ParqueaderoService } from '../../../../servicios/parqueadero.service';
import { Router } from '@angular/router';
import { IParqueadero } from '../../../../interfaces/parqueadero';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { AutenticacionService } from '../../../../servicios/autenticacion.service';
@Component({
  selector: 'app-listado-vehiculos',
  imports:[
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    CommonModule,
    MatTableModule, 
    MatButtonModule
  ],
  templateUrl: './listado-vehiculos.component.html',
  styleUrls: ['./listado-vehiculos.component.css']
})
export class ListadoVehiculosComponent implements OnInit {
  vehiculos: IParqueadero[] = [];
  displayedColumns: string[] = ['tipoVehiculo', 'placa', 'documentoIdentidad', 'horaIngreso', 'horaSalida', 'acciones'];
   
  constructor(private parqueaderoService: ParqueaderoService,private autenticacionService: AutenticacionService, private router: Router) {}

  ngOnInit() {
    this.autenticacionService.Autenticacion().subscribe({
      next: (token) => {
        // Guardar el token en localStorage o algún lugar seguro
        localStorage.setItem('auth_token', token.token); // Asegúrate de que la respuesta tenga el formato adecuado
        console.log('Autenticación exitosa');
      },
      error: (err) => {
        // Manejo de error, si la autenticación falla
        console.error('Error al autenticar:', err);
      }
    });
  
    this.ObtenerVehiculos();
  }
  
  

  ObtenerVehiculos() {
    this.parqueaderoService.ObtenerIngresos().subscribe({
      next: (data) => {
        this.vehiculos = data;
      },
      error: (err) => console.error('Error al obtener vehículos:', err)
    });
  }

  MarcarSalida(ingresoID: number) {
    this.router.navigate(['/salida-form', ingresoID]);
  }

  IrARegistrarIngreso() {
    this.router.navigate(['/ingreso-form']);
  }
}
