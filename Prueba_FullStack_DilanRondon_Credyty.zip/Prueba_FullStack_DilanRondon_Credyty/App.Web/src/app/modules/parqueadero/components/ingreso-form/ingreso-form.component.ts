import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ParqueaderoService } from '../../../../servicios/parqueadero.service';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { Router } from '@angular/router';
@Component({
  imports:[ CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule
  ],
  selector: 'app-ingreso-form',
  templateUrl: './ingreso-form.component.html',
  styleUrls: ['./ingreso-form.component.css']
})
export class IngresoFormComponent{
  ingresoForm: FormGroup;
  private router = inject(Router);
  constructor(private fb: FormBuilder, private parqueaderoService: ParqueaderoService) {
    this.ingresoForm = this.fb.group({
      tipoVehiculo: ['', Validators.required],
      placa: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(10)]],
      documentoIdentidad: ['', Validators.required]
    });
  }
  RegistrarIngreso() {
    if (this.ingresoForm.valid) {
      this.parqueaderoService.RegistrarIngreso(this.ingresoForm.value).subscribe({
       next: () =>{
          alert('Vehículo registrado con éxito');    
          this.router.navigate(['/listado-vehiculos']);
       },
       error(err) {
          console.error(err);
          alert('Error al registrar ingreso');
       },
      });
    }
  }
}
