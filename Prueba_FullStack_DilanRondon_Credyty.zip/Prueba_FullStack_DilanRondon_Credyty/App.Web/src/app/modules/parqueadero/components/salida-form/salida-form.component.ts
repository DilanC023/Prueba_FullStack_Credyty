import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ParqueaderoService } from '../../../../servicios/parqueadero.service';
import { IParqueadero } from '../../../../interfaces/parqueadero';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
@Component({
  selector: 'app-salida-form',
  imports:[
    FormsModule,
    ReactiveFormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    CommonModule,
    MatButtonModule,
    MatCheckboxModule
  ],
  templateUrl: './salida-form.component.html',
  styleUrls: ['./salida-form.component.css']
})
export class SalidaFormComponent implements OnInit {
  salidaForm: FormGroup;
  ingresoID!: number;

  constructor(
    private fb: FormBuilder,
    private parqueaderoService: ParqueaderoService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.salidaForm = this.fb.group({
      placa: [{ value: '', disabled: true }, Validators.required],
      horaIngreso: [{ value: '', disabled: true }, Validators.required],
      valorPagado: [0, [Validators.required, Validators.min(0)]],
      descuentoAplicado: [false]
    });
  }

  ngOnInit() {
    this.ingresoID = Number(this.route.snapshot.paramMap.get('ingresoID'));
    if (this.ingresoID) {
      this.CargarDatosIngreso(this.ingresoID);
    }
  }

  CargarDatosIngreso(id: number) {
    this.parqueaderoService.ObtenerIngresoPorId(id).subscribe({
      next: (data) => {
        this.salidaForm.patchValue({
          placa: data.placa,
          horaIngreso: data.horaIngreso,
          descuentoAplicado: data.descuentoAplicado,
          valorPagado: data.valorPagado
        });
      },
      error: (err) => console.error('Error al obtener datos:', err)
    });
  }

  RegistrarSalida() {
    if (this.salidaForm.valid) {
      const ingresoModificado: IParqueadero = {
        ingresoID: this.ingresoID,
        vehiculoID: 0, // Se mantiene sin cambios
        horaIngreso: this.salidaForm.get('horaIngreso')?.value,
        valorPagado: this.salidaForm.get('valorPagado')?.value,
        descuentoAplicado: this.salidaForm.get('descuentoAplicado')?.value,
        tipoVehiculo: '', // Se mantiene sin cambios
        placa: this.salidaForm.get('placa')?.value,
        documentoIdentidad: '', // Se mantiene sin cambios
      };

      this.parqueaderoService.ModificarIngreso(this.ingresoID, ingresoModificado).subscribe({
        next: () => {
          alert('Salida registrada con éxito');
          this.router.navigate(['/listado-vehiculos']);
        },
        error: (err) => {
          console.error('Error al registrar salida:', err);
          alert('Error al registrar salida');
        }
      });
    }
  }

  IrAFactura() {
    this.router.navigate(['/factura-form', this.ingresoID]);
  }
}
