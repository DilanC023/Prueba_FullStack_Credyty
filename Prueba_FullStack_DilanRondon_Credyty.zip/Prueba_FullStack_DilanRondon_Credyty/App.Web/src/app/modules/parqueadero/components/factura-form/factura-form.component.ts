import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { FacturaService } from '../../../../servicios/factura.service';
import { IFactura } from '../../../../interfaces/factura';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
@Component({
  selector: 'app-factura-form',
  imports:[
    FormsModule,
    ReactiveFormsModule,  // Para trabajar con formularios reactivos
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatButtonModule,
    CommonModule
  ],
  templateUrl: './factura-form.component.html',
  styleUrls: ['./factura-form.component.css']
})
export class FacturaFormComponent implements OnInit {
  facturaForm: FormGroup;
  ingresoID!: number; // Variable para almacenar el ID de ingreso

  constructor(
    private fb: FormBuilder,
    private facturaService: FacturaService,
    private route: ActivatedRoute, 
    private router: Router
  ) {
    this.facturaForm = this.fb.group({
      ingresoID: ['', Validators.required], // Se llenará automáticamente desde la URL
      numeroFactura: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    // Captura el parámetro de la URL y lo asigna al formulario
    this.route.paramMap.subscribe(params => {
      const id = params.get('ingresoID');
      if (id) {
        this.ingresoID = +id;
        this.facturaForm.patchValue({ ingresoID: this.ingresoID });
      }
    });
  }

  AdicionarFactura() {
    if (this.facturaForm.valid) {
      const factura: IFactura = {
        facturaID: 0, // Generado en el backend
        ingresoID: this.ingresoID, // Se toma de la URL
        numeroFactura: this.facturaForm.value.numeroFactura
      };
  
      this.facturaService.AdicionarFactura(factura).subscribe({
        next: (exito) => {
          if (exito) {
            alert('Factura registrada correctamente');
            // Redirigir a salida-form con el ingresoID
            this.router.navigate(['/salida-form', this.ingresoID]);
          } else {
            alert('No se pudo registrar la factura');
          }
        },
        error: (err) => {
          console.error(err);
          alert('Error al registrar la factura');
        }
      });
    }
  }
}
