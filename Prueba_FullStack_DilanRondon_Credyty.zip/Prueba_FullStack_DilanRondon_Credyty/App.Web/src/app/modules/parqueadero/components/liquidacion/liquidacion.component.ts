import { Component } from '@angular/core';

@Component({
  selector: 'app-liquidacion',
  imports: [],
  templateUrl: './liquidacion.component.html',
  styleUrl: './liquidacion.component.css'
})
export class LiquidacionComponent {

}
